﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MariasTestPVA
{
    public partial class Form1 : Form
    {
        private int[] pole;
        int even = 0;
        public Form1()
        {
            InitializeComponent();
            VytvorPole();
            NaplnPole();
            LogikaPole();
        }
   
        private void VytvorPole()
        {
            pole = new int[50];
        }

        private void NaplnPole()
        {
            Random rd = new Random();
            for (int i = 0; i < pole.Length; i++)
            {
                pole[i] = rd.Next(10, 100);
            }
        }

        public int LogikaPole()
        {
            for (int i = 0; i < pole.Length; i++)
            {
                if(pole[i] % 2 == 0)
                {
                    even += pole[i];
                }
            }
            even /= 10;
            return even;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string str = Convert.ToString(even);
            textBox1.Text = str;
        }

        private void ctverec_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            ctverec.BackColor = Color.Orange;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ctverec.Width += 5;
            ctverec.Height += 5;
            if(ctverec.Height + 200 >= this.Height)
            {
                timer1.Enabled = false;
                textBox2.Text = "Dolni";
            }
            if (ctverec.Height + 200 <= 0)
            {
                timer1.Enabled = false;
                textBox2.Text = "Horni";
            }
            if (ctverec.Width + 250 <= 0)
            {
                timer1.Enabled = false;
                textBox2.Text = "Leva";
            }
            if (ctverec.Width + 250 >= this.Width)
            {
                timer1.Enabled = false;
                textBox2.Text = "Prava";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
