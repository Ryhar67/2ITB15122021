﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace forma
{
    public partial class Form1 : Form
    {

         public int[] pole = new int[50];
        public Random rd = new Random();
        
        public void naplnpole()
        {
            for (int i = 0; i < pole.Length ; i++)
            {
                pole[i] = rd.Next(10, 100);
                
            }
            logikapole();
        }
        int soucet = 0;
        public int logikapole()
        {
            
            for (int i = 0; i < pole.Length; i++)
            {
                if (pole[i] == 0)
                {

                }
                else if(pole[i] % 2 == 0)
                {
                    soucet += pole[i];
                }
                else
                {

                }
                
            }
            return soucet/10;
        }
        public Form1()
        {
            InitializeComponent();
        }

        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

         

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
               panel1.Width = int.Parse(textBox2.Text);
               panel1.Height = int.Parse(textBox2.Text);

            
        }

        

        private void fileSystemWatcher1_Changed(object sender, System.IO.FileSystemEventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {
           
            textBox2.Text = panel1.Width.ToString();
           textBox2.Text = panel1.Height.ToString();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void label2_Click(object sender, EventArgs e)
        {

        }
        public int x=200;
        public int y=200;
        public String leva = "";
        public String prava ="";
        public String hore = "";
        public String dole = "";
        public int sirka;
        public int vyska;
        int vel = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            
             vel= 5 + vel;
            textBox2.Text = vel.ToString();
            panel1.Height = int.Parse(textBox2.Text);
            panel1.Width = int.Parse(textBox2.Text);

            if (panel1.Width == this.Width)
            {
                prava = "pravo";
                timer1.Enabled = false;
            }
            if (panel1.Width == 0)
            {
                leva = "leva";
                timer1.Enabled = false;
            }
            if (panel1.Height == this.Height)
            {
                dole = "dole";
                timer1.Enabled = false;
            }
            if (panel1.Height == this.Height)
            {
                hore = "hore";
                timer1.Enabled = false;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            naplnpole();
            textBox2.Text = logikapole().ToString();
            timer1.Enabled = true;
            dole = "";
            hore = "";
            leva = "";
            prava = "";
        }
        private void label1_Click_1(object sender, EventArgs e)
        {
            label1.Text = hore;
        }
        private void label2_Click_1(object sender, EventArgs e)
        {
            label2.Text = dole;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.Text = leva;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label4.Text = prava;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            label1.Text = "" + dole;
            label2.Text = ""+ hore;
            label3.Text = "" +leva;
            label4.Text = "" +prava;
        }

        
    }
}