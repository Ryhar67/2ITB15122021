import java.util.*;


public class kms {
    public static Scanner sc = new Scanner(System.in);
    public static int velikost =0;
    public static int []pole;

    public static void main(String[] args){
        NaplnPole();
        vypisPole();

    }

public static void NaplnPole(){
    System.out.println("napln pole");
    for (int i = 0; i <pole.length; i++){
        sc.nextInt(pole.length);


    }

   if (pole.length == 2){
       for (int i = 0; i <pole.length; i--) {
           for (int j = 0; j <j ; j++) {

           }
       }

   }
   
   }
public static void vypisPole(){


System.out.println(pole);
}
}