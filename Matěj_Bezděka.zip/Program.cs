﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6 {
    class Program {
        public static int[] pole;
        public static Random rnd = new Random();
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            vytvorPole();
            naplnPole();
            logikaPole();
            int logika = logikaPole();
            Application.Run(new Form1(logika));
            
        }

        public static void vytvorPole() {
            pole = new int[50];
        }

        public static void naplnPole() {
            for (int i = 0; i < pole.Length; i++) {
                pole[i] = rnd.Next(10, 100);
            }
        }

        public static int logikaPole() {
            int vysledek = 0;
            for (int i = 0; i < pole.Length; i++) {
                if (pole[i] % 2 == 0) {
                    vysledek += pole[i];
                }
            }

            return vysledek/10;
        }
    }
}