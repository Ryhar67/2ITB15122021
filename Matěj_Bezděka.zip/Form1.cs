﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace WindowsFormsApp6 {
    public partial class Form1 : Form {
        public int zvetseni = 5;
        public Form1(int logika) {
            InitializeComponent();
            textBox1.Text = (logika + "");
            ctverec.Size = new Size(logika, logika);
        }
        private void label1_MouseClick(object sender, MouseEventArgs e) {
            timer1.Start();
        }

        private void timer1_Elapsed(object sender, ElapsedEventArgs e) {
            zmenaVelikosti();
            ctverec.Height += zvetseni;
            ctverec.Width += zvetseni;
            ctverec.Top -= zvetseni / 2;
            ctverec.Left -= zvetseni / 2;
        }
        private void zmenaVelikosti() {
            if (ctverec.Top < 0) { 
                timer1.Stop();
            } else if (ctverec.Height + ctverec.Location.Y >= ClientRectangle.Height) {
                timer1.Stop();
            } else if (ctverec.Left < 0) {
                timer1.Stop();
            } else if (ctverec.Location.X + ctverec.Width >= ClientRectangle.Width) {
                timer1.Stop();
            }
        }


        private void textBox1_TextChanged_1(object sender, EventArgs e) {
            int velikost = Int32.Parse(textBox1.Text);
                ctverec.Size = new Size(velikost, velikost);   
        }
    }
}