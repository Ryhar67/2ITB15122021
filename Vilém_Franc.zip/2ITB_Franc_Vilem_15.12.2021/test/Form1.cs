﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VytvorPole();
            NaplnPole();
            textBox1.Text = LogikaPole().ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public static int[] pole;
        public void VytvorPole()
        {
            pole = new int[50];
        }
        public void NaplnPole()
        {
            for(int i = 0; i<pole.Length; i++)
            {
                Random rd = new Random();
                int random = rd.Next(10,100);
                pole[i] = random;
            }
        }
        public int LogikaPole()
        {
            int x = 0;
            for(int i = 0; i<pole.Length; i++)
            {
                if (pole[i]%2 == 0)
                {
                    x = pole[i] + x;
                }
            }
            int y = x / 10;
            return y;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ctverec.Height = LogikaPole();
            ctverec.Width = LogikaPole();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ctverec.Width += 5;
            ctverec.Height += 5;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 10;
            if (ctverec.Height == 0 || ctverec.Width == 0 || ctverec.Height == 0 || ctverec.Width == 0)
            {
                timer1.Enabled = false;
            }
            if (ctverec.Left == 0)
            {
                textBox1.Text = "Left";
            }
            if (ctverec.Right == 0)
            {
                textBox1.Text = "Right";
            }
            if (ctverec.Top == 0)
            {
                textBox1.Text = "Top";
            }
            if (ctverec.Bottom == 0)
            {
                textBox1.Text = "Bottom";
            }
        }
    }
}
