﻿//autor Jan kopejtko
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public static Random rn = new Random();
        public int[] VytvorPole() 
        {
            int[] pole = new int[50];
            return pole;
        }
        public int[] NaplnPole(int[] pole)
        {
            for(int i = 0; i < pole.Length; i++)
            {
                pole[i] = rn.Next(10, 101);
            }
            return pole;
        }
        public int LogikaPole(int[] pole)
        {
            int sum = 0;
            for (int i = 0; i < pole.Length; i++)
            {
                if(pole[i] % 2 == 0)
                {
                    sum = sum + pole[i];
                }
            }
            sum = sum / 10;
            textBox1.Text = sum.ToString();
            return sum;
        }
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = LogikaPole(NaplnPole(VytvorPole())).ToString();
            ctverec.Width = int.Parse(textBox1.Text);
            ctverec.Height = int.Parse(textBox1.Text);
            ctverec.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            ctverec.Height = LogikaPole(NaplnPole(VytvorPole()));
            ctverec.Width = LogikaPole(NaplnPole(VytvorPole()));
            textBox1.Text = LogikaPole(NaplnPole(VytvorPole())).ToString();
            ctverec.Visible = true;
            timer1.Enabled = true;
            ctverec.BackColor = Color.FromArgb(rn.Next(0, 256), rn.Next(0, 256), rn.Next(0, 256));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ctverec.Height = ctverec.Height + 5;
            ctverec.Width = ctverec.Width + 5;
            if (ctverec.Height + 200 >= this.Height)
            {
                timer1.Enabled = false;
                timer1.Stop();
                MessageBox.Show("Dolní byl první");
            }
            if (ctverec.Width + 250 >= this.Width)
            {
                timer1.Enabled = false;
                timer1.Stop();
                MessageBox.Show("Pravý byl první");
            }
            if (ctverec.Width <= 0)
            {
                timer1.Enabled = false;
                timer1.Stop();
                MessageBox.Show("Levý byl první");
            }
            if (ctverec.Height <= 0)
            {
                timer1.Enabled = false;
                timer1.Stop();
                MessageBox.Show("horní byl první");
            }
        }

        private void ctverec_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
