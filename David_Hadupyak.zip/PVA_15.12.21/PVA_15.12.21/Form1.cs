﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVA_15._12._21
{
    public partial class Form1 : Form
    {
        int[] pole;

        public Form1()
        {
            InitializeComponent();
            VytvorPole();
            NaplnPole();
            textBox1.Text = "" + LogikaPole();
        }

        public void VytvorPole()
        {
            pole = new int[50];
        }

        public void NaplnPole()
        {
            Random rd = new Random();
            for (int i = 0; i < pole.Length; i++)
            {
                pole[i] = rd.Next(10, 100);
            }
        }

        public int LogikaPole()
        {
            int sum = 0;
            for (int i = 0; i < pole.Length; i++)
            {
                if (pole[i] % 2 == 0)
                {
                    sum += pole[i];
                }
            }
            sum = sum / 10;
            return sum;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ctverec.Location = new Point(250, 250);
            ctverec.Size = new Size(int.Parse(textBox1.Text), int.Parse(textBox1.Text));
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ctverec.Size = new Size(ctverec.Size.Width + 5, ctverec.Size.Height + 5);
            if (ctverec.Right - Form1.ActiveForm.Width >= 0)
            {
                Console.WriteLine("Ctverec se dotkl prave strany");
                label2.Text = "Ctverec se dotkl prave strany";
                timer1.Stop();
            }
            if (ctverec.Left - Form1.ActiveForm.Width >= 0)
            {
                Console.WriteLine("Ctverec se dotkl leve strany");
                label2.Text = "Ctverec se dotkl leve strany";
                timer1.Stop();
            }
            if (ctverec.Top - Form1.ActiveForm.Height >= 0)
            {
                Console.WriteLine("Ctverec se dotkl horni strany");
                label2.Text = "Ctverec se dotkl horni strany";
                timer1.Stop();
            }
            if (ctverec.Bottom - Form1.ActiveForm.Height >= 0)
            {
                Console.WriteLine("Ctverec se dotkl spodni strany");
                label2.Text = "Ctverec se dotkl spodni strany";
                timer1.Stop();
            }
        }
    }
}
