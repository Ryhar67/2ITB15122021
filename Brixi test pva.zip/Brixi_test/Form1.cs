﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brixi_test
{
    public partial class Form1 : Form
    {
        Random rd = new Random();
        public int[] pole;
        public int sude;

        public Form1()
        {
            InitializeComponent();
        }
        public int[] VytvorPole()
        {
            pole = new int[50];
            return pole;
            
        }

        public int[] NaplnPole(int[] pole)
        {
            for (int i = 0; i < pole.Length; i++)
            {
                int cisla = rd.Next(10, 100);

                pole[i] = cisla;
            }
            return pole;
        }

        public int LogikaPole(int[] pole)
        {
            for (int i = 0; i < pole.Length; i++)
            {
                if (pole[i]%2 == 0)
                {
                    sude += pole[i];

                    
                }
            }
            sude /= 10;

            return sude;
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            int vysledek = LogikaPole(NaplnPole(VytvorPole()));
            textBox1.Text = vysledek.ToString();
            ctverec.Size = new Size(vysledek, vysledek);
        }

        private void ctverec_Paint(object sender, PaintEventArgs e) //Ctverec
        {

        }

        public void textBox1_TextChanged(object sender, EventArgs e) //Textbox
        {
            // int i = 10;
            // textBox1.Text = i.ToString();
        }

        private void button1_Click(object sender, EventArgs e) //Button
        {
            timer3.Start();

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            ctverec.Size = new Size(ctverec.Size.Width+5, ctverec.Size.Height+5);
            if (ctverec.Top - Form1.ActiveForm.Height > 0)
            {
                timer3.Stop();
                Console.WriteLine("Dotklo se top strany");
            }
            if (ctverec.Bottom - Form1.ActiveForm.Height > 0)
            {
                timer3.Stop();
                Console.WriteLine("Dotklo se bottom strany");
            }
            if (ctverec.Right - Form1.ActiveForm.Width > 0)
            {
                timer3.Stop();
                Console.WriteLine("Dotklo se right strany");
            }
            if (ctverec.Left - Form1.ActiveForm.Width > 0)
            {
                timer3.Stop();
                Console.WriteLine("Dotklo se left strany");
            }
        }
    }
}
