﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestČerný
{
    public partial class Form1 : Form
    {
        public int[] pole;
 
        public Form1()
        {
            InitializeComponent();
            VytvorPole();
            NaplPole();
           
            textBox1.Text = LogikaPole().ToString();

            for (int i = 0; i < pole.Length; i++)
            {
                textBox2.Text += pole[i].ToString();
                textBox2.Text += ", ";
            }
            
        }

        public void VytvorPole()
        {
            
            pole = new int[50];

           
        }

        public void NaplPole()
        {
            Random rn = new Random();

            for (int i = 0; i < pole.Length; i++)
            {
                pole[i] = rn.Next(10, 100);
            }

        }

        public int LogikaPole()
        {
            int vysl = 0;
            for (int i = 0; i < pole.Length; i++)
            {
                if(pole[i] %2 ==0)
                {
                    vysl += pole[i];
                }
                
            }
                vysl /= 10;
            return vysl;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void Timer1Tick(object sender, EventArgs e)
        {
            ctverec.Width += 5;
            ctverec.Height += 5;

            if (ctverec.Width >= this.Width - ctverec.Left)
            {
                timer1.Enabled = false;
                textBox1.Text = "Pravá";
            }
            else
            {
                if(ctverec.Height >= this.Height - ctverec.Top)
                {
                    timer1.Enabled = false;
                    textBox1.Text = "Spodek";
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ctverec.BackColor = Color.Blue;
            ctverec.Height = LogikaPole();
            ctverec.Width = LogikaPole();
            timer1.Enabled = true;
            
            
            
            
        }
    }
}
