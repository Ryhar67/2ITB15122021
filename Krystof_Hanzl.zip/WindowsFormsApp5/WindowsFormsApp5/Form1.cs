﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5 {
    public partial class Form1 : Form {
        private int[] pole;
        private Random rnd = new Random();
        public Form1() {
            InitializeComponent();
            VytvorPole(50);
            NaplnPole(10, 100);
            textBox1.Text = LogikaPole().ToString();
            ctverec.Location = new Point(250, 200);
            ctverec.Visible = false;
        }

        private void VytvorPole(int vel) {
            pole = new int[vel];
        }

        private void NaplnPole(int min, int max) {
            for (int i = 0; i < pole.Length; i++) {
                pole[i] = rnd.Next(min, max);
            }
        }

        private int LogikaPole() {
            int soucet = 0;
            for (int i = 0; i < pole.Length; i++) {
                if (pole[i] % 2 == 0) {
                    soucet += pole[i];
                }
            }

            return soucet / 10;
        }

        private void label1_Click(object sender, EventArgs e) {
            ctverec.Height = Int32.Parse(textBox1.Text);
            ctverec.Width = Int32.Parse(textBox1.Text);
            ctverec.Visible = true;
            
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e) {
            ZvecCtverec(5);
            if (ctverec.Width + ctverec.Location.X >= this.Width) {
                //kontrola pravá
                TimerStop();
                message("Pravá");
            }else if (ctverec.Height + ctverec.Location.Y >= this.Height) {
                //kontrola levá
                TimerStop();
                message("Dolní");
            }else if (ctverec.Location.X <= 0) {
                //kontrola levá
                TimerStop();
                message("Levá");
            }else if(ctverec.Location.Y == 0) {
                //kontrola horní
                TimerStop();
                message("Horní");
            }
        }

        private void ZvecCtverec(int vel) {
            ctverec.Width += vel;
            ctverec.Height += vel;
        }
        private void message(string strana) {
            MessageBox.Show("A vítězem se stává: " + strana + " strana");
        }
        private void TimerStop() {
            timer1.Enabled = false;
        }
    }
}