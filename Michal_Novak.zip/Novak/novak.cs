﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1Novak
{
    public partial class Form1 : Form
    {

        public static int[] pole;
        public static int sude;

        public Form1()
        {
            InitializeComponent();
        }

        public static void VytvorPole()
        {

            pole = new int[50];

        }

        public void NaplnPole()
        {

            Random random = new Random();

            for(int i = 0; i < pole.Length; i++)
            {

                int randomInt = random.Next(10, 100);

                pole[i] = randomInt;

            }

            int vysl =LogikaPole();

            textBox1.Text = vysl.ToString();

        }

        public int LogikaPole()
        {

            for(int k = 0; k < pole.Length; k++)
            {

                if(pole[k]%2 == 0)
                {

                    sude += pole[k];

                }

            }

            sude = sude / 2;

            return sude;
        }

        private void label1_Click(object sender, EventArgs e)
        {

            string text = textBox1.Text;

            int size = int.Parse(textBox1.Text);

            label1.Size = new Size(size, size);


        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            int zvetsit = 5;
            label1.Size = new Size(label1.Width + zvetsit, label1.Height + zvetsit) ;
                
        }
    }
}
