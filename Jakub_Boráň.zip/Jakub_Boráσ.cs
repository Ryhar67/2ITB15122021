﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{


    public partial class Form1 : Form
    {
     
        
        public int LogikaVytvoraNaplnPole()
        {
            int x = 0;
            int[] pole = new int[50];
            Random rd = new Random();
            for (int i = 0; i < pole.Length; i++)
            {
                pole[i] = rd.Next(10, 100);




            }
            for (int i = 0; i < pole.Length; i++)
            {

                if (pole[i] % 2 == 0)

                  
                    x += pole[i];
                
            }
            int a = x / 10;

            return a;

        }
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text =  LogikaVytvoraNaplnPole().ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void ctverec_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;



        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ctverec.Size = new Size (ctverec.Width + 5, ctverec.Height + 5);
              if(ctverec.Left > this.Width - ctverec.Width)
            {
                timer1.Enabled = false;
                label3.Text = "dotknul se pravé strany";

            }


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
